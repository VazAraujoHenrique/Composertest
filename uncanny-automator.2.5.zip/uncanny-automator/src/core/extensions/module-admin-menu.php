<?php

namespace Uncanny_Automator;

if ( ! defined( 'WPINC' ) ) {
	die;
}


/**
 * Class Module_Admin_Menu
 * @package Uncanny_Automator
 * @deprecated v2.1.1
 */
class Module_Admin_Menu {
	public function __construct() {
	}

}